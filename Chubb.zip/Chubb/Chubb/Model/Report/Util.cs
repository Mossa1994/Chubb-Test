﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chubb.Model.Report
{
    public class Util
    {
        public static dynamic GetIngredientsByStore(List<Order> orders, Store store)
        {
            List<Ingredient> allIngredients = new List<Ingredient>();

            foreach (Order order in orders)
            {
                if (order.Store == store || store == null)
                {
                    foreach (Recipe recipe in order.Recipes)
                    {
                        allIngredients.AddRange(recipe.Ingredients);
                    }
                }
            }

            return from ingredient in allIngredients
                   group ingredient by new { ingredient.Id, ingredient.Name, ingredient.Unit } into ingredientGroup
                   select new { Name = ingredientGroup.Key.Name, Unit = ingredientGroup.Key.Unit, Quantities = ingredientGroup.ToList().Sum(i => i.Quantity) };
        }
    }
}
