﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chubb.Model
{
    public enum IngredientUnit
    {
        Piece,
        Bottle,
        Packs,
        Gram,
        TableSpoon,
        Millimetre
    }
    
}
