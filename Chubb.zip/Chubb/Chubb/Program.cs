﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Chubb.Model;
using Chubb.Model.Report;

namespace Chubb
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create a new recipe tiramisu
            Recipe tiramisu = new Recipe() {Name = "Tiramisu"};

            //Add ingredients to recipe tiramisu
            tiramisu.Ingredients = new List<Ingredient>()
            {
                new Ingredient(1,"sugar", IngredientUnit.Gram, 200),
                new Ingredient(2,"mascarpone", IngredientUnit.Gram, 250),
                new Ingredient(3,"cream", IngredientUnit.Millimetre, 250),
                new Ingredient(4,"oil", IngredientUnit.TableSpoon, 3),
                new Ingredient(5,"wine", IngredientUnit.Millimetre, 170),
                new Ingredient(6,"biscuit", IngredientUnit.Piece, 30),
                new Ingredient(7,"egg", IngredientUnit.Piece, 3)
            };

            //Create a new recipe stirFriedRice
            Recipe stirFriedRice = new Recipe() {Name = "Stir Fried Rice" };
            stirFriedRice.Ingredients = new List<Ingredient>()
            {
                new Ingredient(8,"Rice", IngredientUnit.Gram, 500),
                new Ingredient(7,"egg", IngredientUnit.Piece, 3),
                new Ingredient(4,"oil", IngredientUnit.TableSpoon, 4),
                new Ingredient(9,"mushroom", IngredientUnit.Gram, 100),
                new Ingredient(10, "bacon", IngredientUnit.Gram, 50)
            };

            //Create a new recipe steamedSeaBass
            Recipe steamedSeaBass = new Recipe() {Name = "Steamed Sea Bass" };
            steamedSeaBass.Ingredients = new List<Ingredient>()
            {
                new Ingredient(11,"seaBass", IngredientUnit.Gram, 500),
                new Ingredient(4,"oil", IngredientUnit.TableSpoon, 3),
                new Ingredient(12,"soySource", IngredientUnit.TableSpoon, 4),
                new Ingredient(13,"springOnion", IngredientUnit.Gram, 100),
                new Ingredient(5, "wine", IngredientUnit.Millimetre, 50)
            };

            //Create a London Bridge store
            Store londonBridge = new Store { Id = 1, Name = "London Bridge" };

            //Create a Charing Cross store
            Store charingCross = new Store { Id = 2, Name = "Charing Cross" };

            //Customer1 made an order at London Bridge Store
            Order order1 = new Order { OrderId = 1, Store = londonBridge };
            order1.Recipes = new List<Recipe>() { tiramisu, stirFriedRice, stirFriedRice };

            //Customer2 made an order at CharingCross store
            Order order2 = new Order { OrderId = 2, Store = charingCross };
            order2.Recipes = new List<Recipe>() { steamedSeaBass, stirFriedRice};

            //Customer3 made an orrder at London Bridge Store
            Order order3 = new Order { OrderId = 3, Store = londonBridge };
            order3.Recipes = new List<Recipe>() { tiramisu, tiramisu, steamedSeaBass, stirFriedRice };

            List<Order> orders = new List<Order>() { order1, order2, order3 };

            //Generate report for food Provider
            FoodProviderReport foodProviderReport = new FoodProviderReport();
            Console.WriteLine("Ingredients reports of all orders for food provide ");
            foreach (var ingredientQuantities in foodProviderReport.GetIngredientsReport(orders))
            {
                Console.WriteLine("Ingredient : " + ingredientQuantities.Name + " " + ingredientQuantities.Quantities + " " + ingredientQuantities.Unit + (ingredientQuantities.Quantities > 0 ? "s" : ""));
            }


            //Generate reports for chef at London Bridge store
            Console.WriteLine();
            Console.WriteLine("Ingredients reports of all orders for chef at Londn bridge store");
            StoreChefReport storeChefReport = new StoreChefReport(londonBridge);
            foreach(var ingredientQuantities in storeChefReport.GetIngredientsReport(orders))
            {
                Console.WriteLine("Ingredient : " + ingredientQuantities.Name + " " + ingredientQuantities.Quantities + " " + ingredientQuantities.Unit + (ingredientQuantities.Quantities > 0 ? "s" : ""));
            }

            Console.WriteLine();
            Console.WriteLine("Recipes reports of all orders for chef at Londn bridge store");

            foreach(KeyValuePair<Recipe, int> recipeNumberOrdered in storeChefReport.GetRecipesReport(orders))
            {
                Console.WriteLine("Recipe : " + recipeNumberOrdered.Key.Name + " Number ordered : " + recipeNumberOrdered.Value);
                foreach(var ingredient in recipeNumberOrdered.Key.Ingredients)
                {
                    Console.WriteLine(" -- " + "Ingredient :" + ingredient.Name + " " +  ingredient.Quantity  + " " + ingredient.Unit + (ingredient.Quantity > 0 ? "s" : ""));
                }
            }

            Console.ReadLine();

        }

    }
}
