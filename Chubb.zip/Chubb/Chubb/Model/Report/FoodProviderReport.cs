﻿using Chubb.Model.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chubb.Model.Report
{
    public class FoodProviderReport : IIngredientsReport
    {
        public dynamic GetIngredientsReport(List<Order> orders)
        {
            return Util.GetIngredientsByStore(orders, null);
        }
    }
}
