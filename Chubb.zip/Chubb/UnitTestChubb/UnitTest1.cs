﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Chubb.Model.Report;
using Chubb.Model;
using System.Collections.Generic;
using System.Dynamic;

namespace UnitTestChubb
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestGetIngredientsReports()
        {
            Recipe recipe1 = new Recipe();
            recipe1.Ingredients = new List<Ingredient>()
            {
                new Ingredient(1,"sugar", IngredientUnit.Gram, 200),
                new Ingredient(4,"oil", IngredientUnit.TableSpoon, 3)
            };


            Recipe recipe2 = new Recipe();
            recipe2.Ingredients = new List<Ingredient>()
            {
                new Ingredient(1,"sugar", IngredientUnit.Gram, 300),
                new Ingredient(6,"biscuit", IngredientUnit.Piece, 30)
            };

            Store store1 = new Store { Id = 1, Name = "store1" };
            Store store2 = new Store { Id = 2, Name = "store2" };

            Order order1 = new Order { OrderId = 1, Store = store1 };
            order1.Recipes = new List<Recipe>() { recipe1 };

            Order order2 = new Order { OrderId = 2, Store = store2 };
            order2.Recipes = new List<Recipe>() { recipe1,recipe2 };

            Order order3 = new Order { OrderId = 1, Store = store1 };
            order3.Recipes = new List<Recipe>() { recipe2 };

            List<Order> orders = new List<Order>() { order1, order2, order3 };

            FoodProviderReport foodProviderReport = new FoodProviderReport();

            int ingredientsCount = 0;
            decimal sugarQuantities = 0m;
            var ingredientsAllStores = foodProviderReport.GetIngredientsReport(orders);

            foreach (var ingredient in ingredientsAllStores)
            {
                ingredientsCount = ingredientsCount + 1;

                if (ingredient.Name == "sugar")
                {
                    sugarQuantities = sugarQuantities + ingredient.Quantities;
                }
            }

            //expect that number of different ingredients are 3
            Assert.AreEqual(3, ingredientsCount);

            //expect the quantities of sugar is 1000
            Assert.AreEqual(1000, sugarQuantities);
        }
    }
}
