﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chubb.Model.Report.Interface
{
    interface IRecipesReport
    {
        Dictionary<Recipe, int> GetRecipesReport(List<Order> orders);
    }
}
