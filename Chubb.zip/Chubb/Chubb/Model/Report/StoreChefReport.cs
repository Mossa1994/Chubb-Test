﻿using Chubb.Model.Interface;
using Chubb.Model.Report.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chubb.Model.Report
{
    public class StoreChefReport : IIngredientsReport, IRecipesReport
    {
        public Store store { get; set; }

        public StoreChefReport(Store store)
        {
            this.store = store;
        }
        public dynamic GetIngredientsReport(List<Order> orders)
        {
            return Util.GetIngredientsByStore(orders, store);
        }

        //this method returns recipes, number of each recipe ordered at a store
        public Dictionary<Recipe, int> GetRecipesReport(List<Order> orders)
        {
            List<Recipe> recipes = new List<Recipe>();

            foreach (Order order in orders)
            {
                if (order.Store == store || store == null)
                {
                    foreach (Recipe recipe in order.Recipes)
                    {
                        recipes.Add(recipe);
                    }
                }
            }
            
            return recipes.GroupBy(r => r).ToDictionary(r => r.Key, c => c.Count());
        }
    }
}
