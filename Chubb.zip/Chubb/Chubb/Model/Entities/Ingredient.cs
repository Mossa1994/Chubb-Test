﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Chubb.Model;

namespace Chubb.Model
{
    public class Ingredient
    {
        public Ingredient(int id,string name, IngredientUnit unit, decimal quantity)
        {
            Id = id;
            Name = name;
            Unit = unit;
            Quantity = quantity;
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public IngredientUnit Unit { get; set; }

        public decimal Quantity { get; set; }
    }
}
